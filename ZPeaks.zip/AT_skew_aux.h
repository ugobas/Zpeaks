void Skew_comp(float *AT_skew, int *ATS_win,
	       float *GC_skew, int *GCS_win,
	       float *GA_skew, int *GAS_win,
	       float *GC_local,int *GCL_win,
	       char *seq, long L, long Win_ini,
	       long Win_max, float IND_FRAC,
	       float GC, float dGC, float dGCS, float dATS,
	       long site);
long Read_sequence(char **seq, char *file_chr);
void Print_skew(float *score, int *window, long L, char *filename,
		int WINOUT, char *lab);
float GC_ave(char *seq, long L);
float Ave_nuc(char *seq, long L, char nuc);
long Find_motif(long *list, char *motif, char *seq, long L);
void Print_motif(long *list, long Nmot, char *filename, int cr,
		 char *motif, int len);
void Print_GC(char *seq, long L, char *filename, int WINOUT);
