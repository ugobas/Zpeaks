float **L_score(long **x_contr, float **y_contr, float **y_exper,
		      long *nn, int N, int WIN, float minmin, float DAMPSCALE,
		      char *output);
void Read_contr_exp(int CONTR, long ***x_contr,
		    float ***y_contr, float ***y_exper,
		    long **nn, char **file_c, char **file_e, int N, char *outp);
void Print_score(long **x_contr, float **Zscore, long *nn, char **file_e,
		 int N, int WIN, float minmin);
float Mean_counts(float *sd, float **y, long *nn, int N);
float Make_box(float **y_box, float **y,
	       long **x, long *nn, int N, float Damp, int *WIN, float l_EPS);
void  Set_control(float **yc_box, int Nchr, long *nn, float value);
float Likelihood_score_opt_r(float **enhancement, float *AIC, float *rr,
			     float **ye_box, float mre, float **yc_box,
			     float mrc, long *nn, int Ncr, float PARAPEN);
void Rescale_counts(float **y, long *nn, int N, float scale);
int BOXSIZE;
