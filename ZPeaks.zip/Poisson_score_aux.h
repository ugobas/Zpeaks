float **Poisson_score(long **x_contr, float **y_contr, float **y_exper,
		      long *nn, int N, int WIN, float minmin, float DAMPSCALE,
		      char *output);
double Win_ave(float *y, long i, int WD, long nn, float *Damp);
void Read_contr_exp(long ***x_contr, float ***y_contr, float ***y_exper,
		    long **nn, char **file_c, char **file_e, int N, char *outp);
void Print_score(long **x_contr, float **Zscore, long *nn, char **file_e,
		 int N, int WIN, float minmin);
